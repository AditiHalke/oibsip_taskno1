import java.sql.*;
public class UserDao {

	
	public static int save(String UserName,String Password){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into User(UserName,Password) values(?,?)");
			ps.setString(1,UserName);
			ps.setString(2,Password);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	/*public static int delete(int S_Id){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from User where S_Id=?");
			ps.setInt(1,S_Id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}*/

	public static boolean validate(String UserName,String Password){
		boolean status=false;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from User where UserName=? and Password=?");
			ps.setString(1,UserName);
			ps.setString(2,Password);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}

}
