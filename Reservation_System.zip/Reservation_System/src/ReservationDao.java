import java.sql.*;
import java.util.*;

public class ReservationDao {
    
    public static Map<Integer, String> FetchTrainData() {
        Map<Integer, String> trainData = new HashMap<>();
       
       try {
    Connection con = DB.getConnection();
    PreparedStatement ps = con.prepareStatement("SELECT Train_No, Train_Name FROM TrainData");
    ResultSet rs = ps.executeQuery();
    
    while (rs.next()) {
        int trainNumber = rs.getInt("Train_No");
        String trainName = rs.getString("Train_Name");
        trainData.put(trainNumber, trainName);
    }
    
    // Close the resources after data retrieval is complete
    rs.close();
    ps.close();
    con.close();
} catch (Exception e) {
    e.printStackTrace(); // Handle or log the exception appropriately
}

return trainData;
    }
	
public static boolean checkTrainExists(int trainNumber) {
    boolean exists = false;
    try {
        Connection con = DB.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT Train_No FROM TrainData WHERE Train_No = ?");
        ps.setInt(1, trainNumber);
        ResultSet rs = ps.executeQuery();
        exists = rs.next(); // If there's at least one row, the train exists
        con.close();
    } catch (Exception e) {
        e.printStackTrace(); // Handle or log the exception appropriately
    }
    return exists;
}


public static int save(int trainNumber, String trainName, String adharNumber) {
    int status = 0;
    try {
        Connection con = DB.getConnection();

        PreparedStatement ps = con.prepareStatement("INSERT INTO TrainReservation(Train_No, Train_Name, Adhar_No) VALUES (?, ?, ?)");
        ps.setInt(1, trainNumber);
        ps.setString(2, trainName);
        ps.setString(3, adharNumber);
        status = ps.executeUpdate();
        con.close();

        /*if (status > 0) {
            // If the insertion was successful, update the train quantity
            status = updateTrainReservation(trainNumber);
        }*/
    } catch (Exception e) {
        e.printStackTrace(); // Handle or log the exception appropriately
    }
    return status;
}

/*public static int updateTrainReservation(int trainNumber) {
    int status = 0;
    int quantity = 0;
    try {
        Connection con = DB.getConnection();

        PreparedStatement ps = con.prepareStatement("SELECT Quantity FROM TrainReservation WHERE Train_No = ?");
        ps.setInt(1, trainNumber);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            quantity = rs.getInt("Quantity");
        }

        if (quantity > 0) {
            PreparedStatement ps2 = con.prepareStatement("UPDATE Trains SET Quantity = ? WHERE Train_No = ?");
            ps2.setInt(1, quantity - 1);
            ps2.setInt(2, trainNumber); // Set the train number as the second parameter
            status = ps2.executeUpdate();
        }
        con.close();
    } catch (Exception e) {
        e.printStackTrace(); // Handle or log the exception appropriately
    }
    return status;
}*/
}