import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/reservation?characterEncoding=utf8","root","A#bc@123");
		}catch(ClassNotFoundException | SQLException e){System.out.println(e);}
		return con;
	}

}

/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {

    public static void main(String[] args) {
        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/Library"; // Replace 'my_database' with your database name
        String username = "root"; // Replace 'your_username' with your MySQL username
        String password = "A#bc@123"; // Replace 'your_password' with your MySQL password

        // Attempting to establish a connection
        try {
            // Register the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root" ,"A#bc@123");
            System.out.println("Connected to the database!");

            // Perform database operations here...
            
            // Don't forget to close the connection when done
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Print any errors
        }
    }
}*/

    