import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;
import javax.swing.GroupLayout.ParallelGroup;
import javax.swing.GroupLayout.SequentialGroup;
import javax.swing.LayoutStyle;
import javax.swing.SwingWorker;

public class ReservationForm extends JFrame {
	static ReservationForm frame;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
        private JTextField textField_5;
        private JTextField textField_6;
        private JTextField textField_7;
        private JTextField textField_8;
        private JTextField textField_9;
        
public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new ReservationForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}



public ReservationForm(){
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
                
                JLabel lblReservationForm = new JLabel("Reservation Form");
		lblReservationForm.setForeground(Color.DARK_GRAY);
		lblReservationForm.setFont(new Font("Tahoma", Font.PLAIN, 22));
                
                textField_1 = new JTextField();//name
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();//adhar number
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();//gender
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();//contactno
		textField_4.setColumns(10);
                
                textField_5 = new JTextField();//date of journey
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();//destination from
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();//destination to
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();//train no
		textField_8.setColumns(10);
                
                textField_9 = new JTextField();//train name
		textField_9.setColumns(10);
                
                JLabel lblName = new JLabel("Name:");
                
                JLabel lblAdhar_No = new JLabel("Adhar No:");
                
                JLabel lblGender = new JLabel("Gender:");
                
                JLabel lblContact = new JLabel("Contact no:");
                
                JLabel lblDate = new JLabel("Departure Date:");
                
                JLabel lblDestFrm = new JLabel("From Destination:");
                
                JLabel lblTo = new JLabel("To destination:");
                
                JLabel lblTrain_No = new JLabel("Train No:");
                
                JLabel lblTrainName = new JLabel("Train Name:");
                //textField_1.setEditable(false);
                
                
                
                JButton btnConfirm = new JButton("Confirm");
btnConfirm.addActionListener((ActionEvent e) -> {
    try {
        int Train_No = Integer.parseInt(textField_8.getText());
        String Train_Name = textField_9.getText();
        String Adhar_No = textField_2.getText();

        if (ReservationDao.checkTrainExists(Train_No)) {
            int i = ReservationDao.save(Train_No, Train_Name, Adhar_No);
            if (i > 0) {
                JOptionPane.showMessageDialog(ReservationForm.this, "Reservation Successful!");
                Dashboard.main(new String[]{});
                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(ReservationForm.this, "Sorry, unable to Reserve!");
            }
        } else {
            JOptionPane.showMessageDialog(ReservationForm.this, "Sorry, Train No doesn't exist!");
        }
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(ReservationForm.this, "Please enter a valid train number!");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(ReservationForm.this, "An error occurred: " + ex.getMessage());
    }
});

                
                JButton btnBack = new JButton("Back");
		btnBack.addActionListener((ActionEvent e) -> {
                    Dashboard.main(new String[]{});
                    frame.dispose();
                });
                btnBack.setFont(new Font("Tahoma", Font.PLAIN, 13));
              
        JButton btnFetchButton = new JButton("FetchButton");
        btnFetchButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        btnFetchButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        // Perform the database operation in a separate thread
        SwingWorker<Map<Integer, String>, Void> worker = new SwingWorker<>() {
           
            protected Map<Integer, String> doInBackground() throws Exception {
                // Call the function in ReservationDao to fetch train data
                return ReservationDao.FetchTrainData();
            }

            protected void done() {
                try {
                    // Retrieve the result of the database operation
                    Map<Integer, String> trainDataMap = get();
                    
                    // Handle the retrieved train data as needed
                    if (trainDataMap != null && !trainDataMap.isEmpty()) {
                        for (Map.Entry<Integer, String> entry : trainDataMap.entrySet()) {
                            int trainNumber = entry.getKey();
                            String trainName = entry.getValue();
                            // Perform operations with train data as needed
                        }
                    } else {
                        // Handle no data or error case
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    // Handle exceptions here
                }
            }
        };

        // Execute the SwingWorker to perform the database operation
        worker.execute();
    }
});                 

// Create a sequential group for button alignment
GroupLayout gl_contentPane = new GroupLayout(contentPane);
contentPane.setLayout(gl_contentPane);
SequentialGroup buttonGroup = gl_contentPane.createSequentialGroup()
    .addComponent(btnFetchButton)
    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(btnConfirm, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(btnBack);

gl_contentPane.setHorizontalGroup(
    gl_contentPane.createParallelGroup(Alignment.LEADING)
        .addGroup(gl_contentPane.createSequentialGroup()
            .addContainerGap()
            .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                // Existing code for labels and text fields
                // ...
                    .addGroup(gl_contentPane.createSequentialGroup()
                    .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addComponent(lblName, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblAdhar_No, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblGender, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblContact, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblDate, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblDestFrm, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblTo, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblTrain_No, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblTrainName, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE))
                    .addGap(10)
                    .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_5, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_6, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_7, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_8, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField_9, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE))
                    .addGap(20))

                // Newly added button alignment
                .addGroup(Alignment.TRAILING, buttonGroup)
            )
            .addGap(48)
        )
);

gl_contentPane.setVerticalGroup(
    gl_contentPane.createParallelGroup(Alignment.LEADING)
        .addGroup(gl_contentPane.createSequentialGroup()
            .addGap(43)
            // Existing code for label and text field alignment
            // ...
                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblName)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAdhar_No)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblGender)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblContact)
						.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDate)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                        .addGap(26)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDestFrm)
						.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                        .addGap(26)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTo)
						.addComponent(textField_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                        .addGap(26)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTrain_No)
						.addComponent(textField_8, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                        .addGap(26)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTrainName)
						.addComponent(textField_9, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                        .addGap(26)

            // Buttons aligned vertically
            .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                // Align the buttons in a row
                .addComponent(btnFetchButton)
                .addComponent(btnConfirm)
                .addComponent(btnBack)
            )
            .addGap(25)
        )
);

contentPane.setLayout(gl_contentPane);
}
}