/*import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CancellationDao {
	public static int delete(int Train_No, long Adhar_No){
		int status=0;
		try{
			Connection con=DB.getConnection();
			
			//status=updateTrainReservation(Train_No);//updating quantity and issue
			
			if(status>0){
			PreparedStatement ps=con.prepareStatement("delete from TrainReservation where Train_No=? and Adhar_No=?");
			ps.setInt(1,Train_No);
			ps.setInt(2, (int) Adhar_No);
			status=ps.executeUpdate();
			}
			
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	/*public static int updateTrainReservation(int Train_No){
		int status=0;
		int Quantity=0;
		try{
			Connection con=DB.getConnection();
			
			PreparedStatement ps=con.prepareStatement("SELECT Train_Name from TrainReservation where Adhar_No=?");
			ps.setInt(1,Train_No);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				Quantity=rs.getInt("Quantity");
				//Issued=rs.getInt("issued");
			}
			
			/*if(Issued>0){
			PreparedStatement ps2=con.prepareStatement("update books set quantity=?,issued=? where callno=?");
			ps2.setInt(1,Quantity+1);
			ps2.setInt(2,Issued-1);
			ps2.setString(3,bookcallno);
			
			status=ps2.executeUpdate();
			}
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}*/

import java.sql.Connection;
import java.sql.PreparedStatement;

public class CancellationDao {
    public static int delete(int Train_No, long Adhar_No) {
        int status = 0;
        try {
            Connection con = DB.getConnection();

            // Uncomment this line if it's meant for updating train reservations
            // status = updateTrainReservation(Train_No);

            PreparedStatement ps = con.prepareStatement("delete from TrainReservation where Train_No=? and Adhar_No=?");
            ps.setInt(1, Train_No);
            ps.setLong(2, Adhar_No); // Using setLong for a long value

            status = ps.executeUpdate();
            
            con.close();
        } catch (Exception e) {
            // Handle exceptions appropriately, log them for debugging
            e.printStackTrace(); // Logging the stack trace for debugging purposes
            // You might want to throw or handle the exception more elegantly
        }
        return status;
    }
}

